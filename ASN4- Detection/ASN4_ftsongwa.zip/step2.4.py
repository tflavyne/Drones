import cv2

cap = cv2.VideoCapture("Vid,mp4")


while(cap.isOpened()):

    ret, frame = cap.read()
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    for i in range(3):
        template = cv2.imread('step2.1 .png', 0)
        w, h = template.shape[::-1]

        res = 